const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('fixit', {
  getSystemInfo: () => ipcRenderer.invoke('system:info'),
  getDisks: () => ipcRenderer.invoke('system:disks'),
  getNetwork: () => ipcRenderer.invoke('system:network'),
  openUrl: (url) => ipcRenderer.invoke('app:openUrl', url),
  saveReport: (report) => ipcRenderer.invoke('app:saveReport', report)
});