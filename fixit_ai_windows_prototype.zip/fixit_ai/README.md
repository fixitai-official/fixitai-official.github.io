# FIXIT AI (prototype)

A privacy-conscious Windows desktop prototype for basic, read-only system diagnostics and beginner-friendly troubleshooting.

## Requirements
- Windows 10 or 11
- Node.js LTS (includes npm)
- Internet access for the first dependency install

## Run
1. Extract this folder.
2. Open PowerShell in the `fixit_ai` folder.
3. Run `npm install`
4. Run `npm start`

The first install downloads Electron from npm. After that, launch with `npm start`.

## Features in this prototype
- Read-only memory snapshot and CPU model/core count.
- Windows local drive capacity/free-space checks.
- Local IPv4 interface listing (does not prove internet access).
- Battery information when Windows exposes it.
- Guided first steps for slow PC, storage and Wi-Fi issues.
- Save a local text diagnostic report after choosing a destination.

## Important limitations
- This is not connected to an AI model yet.
- It does not measure CPU utilization over time, internet speed, battery health, or the cause of every issue.
- Troubleshooting advice is general and not a guarantee of a fix.
- It does not perform repairs or change system settings.
- Metrics may be unavailable on some devices or Windows configurations.

## Security notes
Electron uses context isolation, disabled Node integration in the renderer, a preload bridge, and a restrictive Content Security Policy. The only external URLs opened by the app are a small allowlist of HTTPS support/test sites. Review code before running software from any source.

## Project files
- `main.js`: Electron main process and local diagnostic handlers
- `preload.js`: narrow API bridge to the interface
- `index.html`: application screens
- `styles.css`: interface styling
- `renderer.js`: UI logic and guided troubleshooting
