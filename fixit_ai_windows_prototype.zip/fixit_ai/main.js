const { app, BrowserWindow, ipcMain, shell } = require('electron');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 650,
    backgroundColor: '#080d16',
    title: 'FIXIT AI',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('system:info', async () => {
  const cpus = os.cpus();
  const total = os.totalmem();
  const free = os.freemem();
  let battery = { available: false, message: 'Battery details are not available from this basic diagnostic.' };
  if (process.platform === 'win32') {
    battery = await new Promise(resolve => {
      execFile('powershell.exe', ['-NoProfile', '-Command',
        '$b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue; if ($b) { $b | Select-Object EstimatedChargeRemaining, BatteryStatus | ConvertTo-Json -Compress }'],
        { timeout: 5000, windowsHide: true }, (err, stdout) => {
          try {
            const b = JSON.parse(stdout.trim());
            resolve({ available: true, percent: b.EstimatedChargeRemaining, status: b.BatteryStatus });
          } catch { resolve({ available: false, message: 'Battery information is unavailable on this device.' }); }
        });
    });
  }
  return {
    platform: `${os.type()} ${os.release()}`,
    hostname: os.hostname(),
    cpu: cpus[0]?.model || 'Unknown CPU',
    cores: cpus.length,
    totalRam: total,
    freeRam: free,
    usedRam: total - free,
    uptimeSeconds: os.uptime(),
    battery
  };
});

ipcMain.handle('system:disks', async () => {
  if (process.platform !== 'win32') return [];
  return new Promise(resolve => {
    const command = 'Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID,Size,FreeSpace | ConvertTo-Json -Compress';
    execFile('powershell.exe', ['-NoProfile', '-Command', command],
      { timeout: 7000, windowsHide: true }, (err, stdout) => {
        if (err || !stdout.trim()) return resolve([]);
        try {
          const d = JSON.parse(stdout.trim());
          resolve((Array.isArray(d) ? d : [d]).map(x => ({
            name: x.DeviceID,
            size: Number(x.Size || 0),
            free: Number(x.FreeSpace || 0)
          })));
        } catch { resolve([]); }
      });
  });
});

ipcMain.handle('system:network', async () => {
  const interfaces = os.networkInterfaces();
  const results = [];
  for (const [name, entries] of Object.entries(interfaces)) {
    for (const entry of entries || []) {
      if (entry.family === 'IPv4' && !entry.internal) results.push({ name, address: entry.address });
    }
  }
  return results;
});

ipcMain.handle('app:openUrl', async (_event, url) => {
  let parsed;
  try { parsed = new URL(url); } catch { throw new Error('Invalid URL.'); }
  const allowedHosts = new Set(['support.microsoft.com', 'www.google.com', 'www.speedtest.net']);
  if (parsed.protocol !== 'https:' || !allowedHosts.has(parsed.hostname)) {
    throw new Error('This link is not on the allowed list.');
  }
  await shell.openExternal(parsed.href);
  return true;
});

ipcMain.handle('app:saveReport', async (_event, report) => {
  const { dialog } = require('electron');
  const win = BrowserWindow.getFocusedWindow();
  const result = await dialog.showSaveDialog(win, {
    title: 'Save FIXIT AI diagnostic report',
    defaultPath: 'fixit-diagnostic-report.txt',
    filters: [{ name: 'Text files', extensions: ['txt'] }]
  });
  if (result.canceled || !result.filePath) return { saved: false };
  const safeText = String(report).slice(0, 20000);
  fs.writeFileSync(result.filePath, safeText, 'utf8');
  return { saved: true, path: result.filePath };
});