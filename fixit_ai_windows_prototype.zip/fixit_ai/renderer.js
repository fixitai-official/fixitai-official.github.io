const $ = (id) => document.getElementById(id);
let lastInfo = null, lastDisks = [], lastNetwork = [];

function fmtBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return 'Unavailable';
  const units = ['B','KB','MB','GB','TB']; let n = bytes, i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}
function fmtDuration(seconds) {
  const d = Math.floor(seconds / 86400), h = Math.floor(seconds % 86400 / 3600), m = Math.floor(seconds % 3600 / 60);
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m`;
}
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function navigate(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === `view-${view}`));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  const titles = {overview:'Overview', diagnose:'Diagnose a problem', system:'System health', guides:'Fix guides'};
  $('page-title').textContent = titles[view] || 'Overview';
  if (view === 'system') refreshSystem();
}
async function refreshSystem() {
  $('report-status').textContent = '';
  try {
    const [info, disks, network] = await Promise.all([window.fixit.getSystemInfo(), window.fixit.getDisks(), window.fixit.getNetwork()]);
    lastInfo = info; lastDisks = disks; lastNetwork = network;
    renderInfo(info, disks, network);
  } catch (e) {
    $('report-status').textContent = `Could not read system information: ${e.message}`;
  }
}
function renderInfo(info, disks, network) {
  const usedPct = info.totalRam ? Math.round(info.usedRam / info.totalRam * 100) : 0;
  $('ram-value').textContent = `${usedPct}%`;
  $('ram-note').textContent = `${fmtBytes(info.usedRam)} of ${fmtBytes(info.totalRam)} memory`;
  $('ram-bar').style.width = `${usedPct}%`;
  $('cpu-value').textContent = info.cores ? `${info.cores} cores` : 'Unavailable';
  $('cpu-note').textContent = info.cpu;
  const totalDisk = disks.reduce((s,d)=>s+d.size,0), freeDisk = disks.reduce((s,d)=>s+d.free,0);
  $('disk-value').textContent = disks.length ? fmtBytes(freeDisk) : 'Unavailable';
  $('disk-note').textContent = disks.length ? `Free across ${disks.length} drive${disks.length===1?'':'s'}` : 'Drive metrics unavailable';
  $('net-value').textContent = network.length ? 'Connected locally' : 'No local IP found';
  $('net-note').textContent = network.length ? `${network.length} network address${network.length===1?'':'es'} detected` : 'This does not confirm internet access';
  $('device-name').textContent = info.hostname || 'This PC';
  $('os-name').textContent = info.platform || 'Unavailable';
  $('cores').textContent = info.cores || 'Unavailable';
  $('uptime').textContent = fmtDuration(info.uptimeSeconds || 0);
  $('battery').textContent = info.battery?.available ? `${info.battery.percent}% (reported)` : 'Not available';
  $('sys-ram').textContent = `${usedPct}% used`;
  $('sys-ram-bar').style.width = `${usedPct}%`;
  $('sys-ram-used').textContent = fmtBytes(info.usedRam);
  $('sys-ram-free').textContent = fmtBytes(info.freeRam);
  $('sys-ram-total').textContent = fmtBytes(info.totalRam);
  $('disk-list').innerHTML = disks.length ? disks.map(d => {
    const pct = d.size ? Math.round((d.size-d.free)/d.size*100) : 0;
    return `<div class="disk-item"><div class="disk-head"><b>${esc(d.name)}</b><span>${fmtBytes(d.free)} free of ${fmtBytes(d.size)}</span></div><div class="progress"><span style="width:${pct}%;${pct>=90?'background:#f5c26b':''}"></span></div>${pct>=90?'<div class="disk-warning">Low free space. Review Windows Storage settings before deleting files.</div>':''}</div>`;
  }).join('') : '<p class="result-summary">No drive information returned. This can happen on unsupported systems.</p>';
  $('network-list').innerHTML = network.length ? network.map(n => `<div class="network-item"><b>${esc(n.name)}</b><span>${esc(n.address)}</span></div>`).join('') : '<p class="result-summary">No non-internal IPv4 address was detected. This does not prove the internet is down.</p>';
}
function diagnose(problem) {
  const result = $('diagnosis-result'); result.classList.remove('hidden');
  let title = '', summary = '', findings = [];
  if (problem === 'slow') {
    title = 'Slow computer: first checks';
    summary = 'These checks look for common causes. They do not prove a single cause of slowness.';
    const pct = lastInfo?.totalRam ? Math.round(lastInfo.usedRam/lastInfo.totalRam*100) : null;
    findings = [
      {label:'LOCAL CHECK', title:'Memory snapshot', body:pct===null?'Memory usage could not be read. Refresh system information and try again.':`Current memory use is ${pct}%. ${pct>=85?'This is high at the moment; check Task Manager for apps using memory.':'This snapshot alone does not show unusually high memory use.'}`},
      {label:'SAFE STEP', title:'Review running apps', body:'Press Ctrl + Shift + Esc to open Task Manager. Check CPU, Memory and Disk columns. Close only apps you recognize and are not using.'},
      {label:'SAFE STEP', title:'Restart and compare', body:'Save your work, restart Windows, then check whether the problem remains. If the device is hot or fan noise is unusual, let it cool and keep vents clear.'}
    ];
  } else if (problem === 'storage') {
    title = 'Storage: available space';
    summary = 'The app checks local drive space but will not delete anything for you.';
    findings = lastDisks.length ? lastDisks.map(d => {
      const pct = d.size ? Math.round((d.size-d.free)/d.size*100) : 0;
      return {label:pct>=90?'REVIEW SOON':'DRIVE CHECK',title:`Drive ${d.name}: ${pct}% used`,body:`${fmtBytes(d.free)} free of ${fmtBytes(d.size)}. ${pct>=90?'Review Settings → System → Storage and inspect temporary files before removing anything.':'If you are experiencing storage errors, review Windows Storage settings for details.'}`};
    }) : [{label:'CHECK UNAVAILABLE',title:'Drive space could not be read',body:'Open Settings → System → Storage in Windows to review free space.'}];
    findings.push({label:'SAFE STEP',title:'Use Windows Storage settings',body:'Open Settings → System → Storage. Review the categories and back up important files. Do not delete unfamiliar system folders.'});
  } else if (problem === 'wifi') {
    title = 'Network: first checks';
    summary = 'This checks local network addresses only. A local address does not guarantee internet access.';
    findings = [
      {label:'LOCAL CHECK',title:'Network interface snapshot',body:lastNetwork.length?`Found ${lastNetwork.length} non-internal IPv4 address(es). That suggests a network interface has a local address, but internet access has not been tested.`:'No non-internal IPv4 address was found. Wi-Fi may be disconnected, or the address may be unavailable.'},
      {label:'SAFE STEP',title:'Compare with another device',body:'Check whether another device on the same Wi-Fi can access a website. This helps separate a laptop issue from a router or provider issue.'},
      {label:'SAFE STEP',title:'Reconnect carefully',body:'Confirm airplane mode is off and Wi-Fi is enabled. Reconnect to your known network. Do not share your Wi-Fi password with troubleshooting tools.'}
    ];
  } else return;
  result.innerHTML = `<div class="result-title">${esc(title)}</div><p class="result-summary">${esc(summary)}</p>${findings.map(f=>`<div class="finding"><div class="label">${esc(f.label)}</div><b>${esc(f.title)}</b><p>${esc(f.body)}</p></div>`).join('')}<p class="result-summary">Did this help? Try the steps one at a time. FIXIT AI does not change settings automatically.</p>`;
  result.scrollIntoView({behavior:'smooth',block:'nearest'});
}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.go)));
document.querySelectorAll('[data-problem]').forEach(b=>b.addEventListener('click',async()=>{
  if (!lastInfo) await refreshSystem();
  diagnose(b.dataset.problem);
  navigate('diagnose');
  diagnose(b.dataset.problem);
}));
$('refresh').addEventListener('click',refreshSystem);
$('system-refresh').addEventListener('click',refreshSystem);
$('custom-submit').addEventListener('click',()=>{
  const text = $('custom-text').value.trim();
  const out = $('custom-result'); out.classList.remove('hidden');
  if (!text) { out.textContent = 'Describe the issue first so you can get relevant general guidance.'; return; }
  const low = text.toLowerCase();
  let advice = 'Write down the exact error message, when the issue began, and whether anything changed recently. Save your work and avoid downloading unknown “fix” tools. Try one change at a time and stop if a step looks different from the instructions.';
  if (/hot|heat|fan|overheat/.test(low)) advice = 'Keep the laptop on a hard, flat surface and ensure vents are unobstructed. Save work and shut down if it becomes unusually hot, smells burnt, or repeatedly powers off. Do not open the laptop while powered on. If overheating persists, ask a qualified technician to inspect it.';
  else if (/install|setup|update|error|crash/.test(low)) advice = 'Copy the exact error text and note the app name and when it appears. Restart the app, check the software publisher’s official support page, and avoid running scripts or installers from unknown sources.';
  else if (/internet|wifi|wi-fi|network/.test(low)) advice = 'Check whether other devices can access the same network, verify airplane mode is off, and reconnect to your known network. Record any exact error before resetting network settings.';
  else if (/battery|charge/.test(low)) advice = 'Check whether Windows shows charging, inspect the cable and adapter for visible damage, and try a known-good compatible outlet. Stop using a damaged or swollen battery and seek qualified repair.';
  out.innerHTML = `<b>Safe first steps</b><br>${esc(advice)}<br><br><span style="color:#64e4dd">Note:</span> This is general guidance, not an AI diagnosis. FIXIT AI has not analyzed your device beyond the local checks shown above.`;
});
$('save-report').addEventListener('click',async()=>{
  if (!lastInfo) await refreshSystem();
  const lines = ['FIXIT AI — LOCAL DIAGNOSTIC REPORT',`Generated: ${new Date().toLocaleString()}`,'','SYSTEM',`Device: ${lastInfo?.hostname || 'Unavailable'}`,`OS: ${lastInfo?.platform || 'Unavailable'}`,`CPU: ${lastInfo?.cpu || 'Unavailable'}`,`CPU cores: ${lastInfo?.cores || 'Unavailable'}`,`RAM total: ${fmtBytes(lastInfo?.totalRam)}`,`RAM used: ${fmtBytes(lastInfo?.usedRam)}`,`RAM available: ${fmtBytes(lastInfo?.freeRam)}`,`Uptime: ${fmtDuration(lastInfo?.uptimeSeconds || 0)}`,'','DRIVES',...lastDisks.map(d=>`${d.name}: ${fmtBytes(d.free)} free of ${fmtBytes(d.size)}`),'','NETWORK INTERFACES',...lastNetwork.map(n=>`${n.name}: ${n.address}`),'','Privacy note: This report contains local system details and network IP addresses. Review it before sharing. No report is uploaded by FIXIT AI.'];
  const res = await window.fixit.saveReport(lines.join('\n'));
  $('report-status').textContent = res.saved ? `Report saved to ${res.path}` : 'Report save cancelled.';
});
refreshSystem();
